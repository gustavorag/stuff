select distinct senderAddress
from june
where deliveryMethod like 'Zix%'
order by senderAddress asc
;
