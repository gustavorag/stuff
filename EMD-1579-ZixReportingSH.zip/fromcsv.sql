select distinct from_address
from june
where direction = 'encode'
and regime like 'zix%'
order by from_address asc
;
